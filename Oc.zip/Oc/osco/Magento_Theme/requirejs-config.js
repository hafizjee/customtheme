var config = {
    paths: {
            'bootstrap':'Magento_Theme/js/bootstrap.min',
    } ,
    shim: {
        'bootstrap': {
            'deps': ['jquery']
        }
    }
};
