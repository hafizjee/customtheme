var config = {

 // When load 'requirejs' always load the following files also
 deps: [
   "js/main"
 ]

};