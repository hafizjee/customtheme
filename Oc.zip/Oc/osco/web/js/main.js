define([
'jquery',
'jquery/ui'
],
function($) {
"use strict";
  //============================
  $(document).ready(function(){
    if (window.matchMedia("(min-width: 768px)").matches) {
      $('#togBtn3').on('change',function(){
        if ($('#togBtn3').is(":checked"))
        {
          $('#pricing').text('ON');
          $('#pricing').css('color','#36BE46');
          localStorage.setItem("togBtn3", "true");
          $(".price-box.price-final_price, .prices-tier.items").show();
        }
        else
        {
          $('#pricing').text('OFF');
          $('#pricing').css('color','#FF4541');
          localStorage.setItem("togBtn3", "false");
          $(".price-box.price-final_price, .prices-tier.items").hide();
        }
      });
    }
  })
   //=========button2=================
  $(document).ready(function(){
    if (window.matchMedia("(min-width: 768px)").matches) {
      $('#togBtn2').on('change',function(){
        if ($('#togBtn2').is(":checked"))
        {
          $('#msrp-price').text('ON');
          $('#msrp-price').css('color','#36BE46');
          localStorage.setItem("togBtn2", "true");
          $(".attributes-data.MSRP.Price").show();
        }
        else
        {
          $('#msrp-price').text('OFF');
          $('#msrp-price').css('color','#FF4541');
          localStorage.setItem("togBtn2", "false");
          $(".attributes-data.MSRP.Price").hide();
        }
      });
    }
  })
  //=========button2=================
  $(document).ready(function(){
    if (window.matchMedia("(min-width: 768px)").matches) {
      $('#togBtn1').on('change',function(){
        if ($('#togBtn1').is(":checked"))
        {
          $('#map-price').text('ON');
          $('#map-price').css('color','#36BE46');
          localStorage.setItem("togBtn1", "true");
          $(".attributes-data.Map.Price").show();
        }
        else
        {
          $('#map-price').text('OFF');
          $('#map-price').css('color','#FF4541');
          localStorage.setItem("togBtn1", "false");
          $(".attributes-data.Map.Price").hide();
        }
      });
    }
  })
  //Header button
  $(document).ready(function(){
    var togBtn1=localStorage.getItem("togBtn1");
    var togBtn2=localStorage.getItem("togBtn2");
    var togBtn3=localStorage.getItem("togBtn3");
    //===================button============
    if(togBtn1==null || togBtn1=="true"){
      $("#togBtn1").prop("checked", true);
      $('#map-price').text('ON');
      $('#map-price').css('color','#36BE46');
      $(".attributes-data.Map.Price").show();

    }else if (togBtn1=="false"){
      $("#togBtn1").prop("checked", false);
      $('#map-price').text('OFF');
      $('#map-price').css('color','#FF4541');
      $(".attributes-data.Map.Price").hide();
    }
    //===================button============
    if(togBtn2==null || togBtn2=="true"){
      $("#togBtn2").prop("checked", true);
      $('#msrp-price').text('ON');
      $('#msrp-price').css('color','#36BE46');
      $(".attributes-data.MSRP.Price").show();
    }else if (togBtn2=="false"){
      $("#togBtn2").prop("checked", false);
      $('#msrp-price').text('OFF');
      $('#msrp-price').css('color','#FF4541');
      $(".attributes-data.MSRP.Price").hide();
    }
    //============buttton3============
    if(togBtn3==null || togBtn3=="true"){
      $("#togBtn3").prop("checked", true);
      $('#pricing').text('ON');
      $('#pricing').css('color','#36BE46');
      $(".price-box.price-final_price, .prices-tier.items").show();
    }else if (togBtn3=="false"){
      $("#togBtn3").prop("checked", false);
      $('#pricing').text('OFF');
      $('#pricing').css('color','#FF4541');
      $(".price-box.price-final_price, .prices-tier.items").hide();
    }
    $(".content.account-nav-content li:last-child" ).click(function(){
     localStorage.removeItem("togBtn1");
     localStorage.removeItem("togBtn2");
     localStorage.removeItem("togBtn3");
      console.log("its working fine");
    });
  })
  //======================================
  $(document).ajaxComplete(function(){
    var togBtn1=localStorage.getItem("togBtn1");
    var togBtn2=localStorage.getItem("togBtn2");
    var togBtn3=localStorage.getItem("togBtn3");
    //===================button============
    if(togBtn1==null || togBtn1=="true"){
      $("#togBtn1").prop("checked", true);
      $('#map-price').text('ON');
      $('#map-price').css('color','#36BE46');
      $(".attributes-data.Map.Price").show();

    }else if (togBtn1=="false"){
      $("#togBtn1").prop("checked", false);
      $('#map-price').text('OFF');
      $('#map-price').css('color','#FF4541');
      $(".attributes-data.Map.Price").hide();
    }
    //===================button============
    if(togBtn2==null || togBtn2=="true"){
      $("#togBtn2").prop("checked", true);
      $('#msrp-price').text('ON');
      $('#msrp-price').css('color','#36BE46');
      $(".attributes-data.MSRP.Price").show();
    }else if (togBtn2=="false"){
      $("#togBtn2").prop("checked", false);
      $('#msrp-price').text('OFF');
      $('#msrp-price').css('color','#FF4541');
      $(".attributes-data.MSRP.Price").hide();
    }
    //============buttton3============
    if(togBtn3==null || togBtn3=="true"){
      $("#togBtn3").prop("checked", true);
      $('#pricing').text('ON');
      $('#pricing').css('color','#36BE46');
      $(".price-box.price-final_price, .prices-tier.items").show();
    }else if (togBtn3=="false"){
      $("#togBtn3").prop("checked", false);
      $('#pricing').text('OFF');
      $('#pricing').css('color','#FF4541');
      $(".price-box.price-final_price, .prices-tier.items").hide();
    }
    $(".content.account-nav-content li:last-child" ).click(function(){
      localStorage.removeItem("togBtn1");
      localStorage.removeItem("togBtn2");
      localStorage.removeItem("togBtn3");
        console.log("its working fine");
    });
  })
  //================================
  // ======search bar header toogle functionality=======//
  $(document).ready(function(){
    $('.search_icon').click(function () {
        $(".block-search .block-content").toggle();
      $(".toggle_menu_div").toggleClass("toogle_search")
    });
  })
  //============================================
  $( document ).ready(function() {
    if (window.matchMedia("(max-width: 767px)").matches) {
      $(".sections.toggle_menu_div.toogle_search").addClass("nav-sections");
    }
    var url = $(location).attr('href'),
    parts = url.split("/"),
    last_part = parts[parts.length-1];
    if(last_part=="faqs"){
      $("#faqs-link").css("color","#00B4FF");
    }
    else if(last_part=="privacy-policy"){
      $("#privacy-policy-link").css("color","#00B4FF");
    }
    else if(last_part=="ordering-information"){
     $("#ordering-information").css("color","#00B4FF");
    }
    else if(last_part=="product-information"){
      $("#product-information").css("color","#00B4FF");
    }
    else if(last_part=="product-fulfillment"){
      $("#product-fulfillment").css("color","#00B4FF");
    }
    else if(last_part=="shipment-returns"){
      $("#shipment-returns").css("color","#00B4FF");
    }
    else if(last_part=="billing-information"){
      $("#billing-information").css("color","#00B4FF");
    }
    else if(last_part=="catalogs"){
      $(".nav-1 a").css("color","#00B4FF");
    }
    else if(last_part=="about-us"){
      $(".static_page_about_us a").css("color","#00B4FF");
    }
    else if(last_part=="contact-us"){
      $(".static_page_contact_us a").css("color","#00B4FF");
    }
     else if(last_part=="orderbysku"){
      $(".nav-2 a").css("color","#00B4FF");
    }
    else {
      $("#terms-conditions-link").css("color","#00B4FF");
    }
  });
  //============header link active==========
  //========contact us border color on click in input field=====//
  $(document).ready(function(){
    $("#email").focus(function(){
     $(".control.email").addClass("border");
    $(".control.password").removeClass("border");
    });
    $("#pass").focus(function(){pass
       $(".control.password").addClass("border");
      $(".control.email").removeClass("border");
    });
  })
    //=====toogle_button 1 header desktop====//
    //=====toogle_button 1 header mob====//
  $(document).ready(function(){
    if (window.matchMedia("(max-width: 500px)").matches) {
      $(function() {
        $(document).on('change','#togBtn1',function(e) {
          var val= $('#togBtn1').is(":checked");
          if(val==true)
          {
            $('.map span').text('OFF');
            $('.map span').css('color','#FF4541');
            $('#togBtn1').prop('checked',false);
             localStorage.setItem("togBtn3", "false");
            $(".table.additional-attributes tr:last-child").show();
          }
          else
          {
            $('.map span').text('ON');
            $('.map span').css('color','#36BE46');
            $('#togBtn1').prop('checked',true);
            localStorage.setItem("togBtn3", "true");
            $(".table.additional-attributes tr:last-child").hide();
          }
        });
      });
    }
  })
  //=====toogle_button 2 header mob====//
  $(document).ready(function(){
    if (window.matchMedia("(max-width: 500px)").matches) {
      $(function() {
        $(document).on('change','#togBtn2',function(e) {
          var val= $('#togBtn2').is(":checked");
          if(val==true)
          {
            $('.msrp-price span').text('OFF');
            $('.msrp-price span').css('color','#FF4541');
            $('#togBtn2').prop('checked',false);
            localStorage.setItem("togBtn3", "false");
            $(".table.additional-attributes tr:first-child").show();
          }
          else
          {
            $('.msrp-price span').text('ON');
            $('.msrp-price span').css('color','#36BE46');
            $('#togBtn2').prop('checked',true);
              localStorage.setItem("togBtn3", "true");
            $(".table.additional-attributes tr:first-child").hide();
          }
        });
      });
    }
  })
    //=====toogle_button 3 header desktop====//
    //=====toogle_button 3 header mob====//
  $(document).ready(function(){
    if (window.matchMedia("(max-width: 500px)").matches) {
      $(function() {
        $(document).on('change','#togBtn3',function(e) {
          var val= $('#togBtn3').is(":checked");
          if(val==true)
          {
            $('.pricing span').text('OFF');
            $('.pricing span').css('color','#FF4541');
            $('#togBtn3').prop('checked',false);
            localStorage.setItem("togBtn3", "false");
            $(".price-box.price-final_price").show();

          }
          else
          {
            $('.pricing span').text('ON');
            $('.pricing span').css('color','#36BE46');
            $('#togBtn3').prop('checked',true);
            localStorage.setItem("togBtn3", "true");
            $(".price-box.price-final_price").hide();
          }
        });
      });
    }
  })
  $(document).ready(function(){
    $('#myInput').keyup(function(){
    // Search text
    var text = $(this).val();
    // Hide all content class element
    $('.content').hide();
    // Search and show
    $('.question:contains("'+text+'")').parent( ".content" ).show();

    });
  });
  $.expr[":"].contains = $.expr.createPseudo(function(arg) {
    return function( elem ) {
      return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
    };
  });
  //PDP incerment /decrement button
  $(document).ready(function(){
    $('#myInput').keyup(function(){
    // Search text
    var text = $(this).val();
      // Hide all content class element
      $('.content').hide();
      // Search and show
      $('.question:contains("'+text+'")').parent( ".content" ).show();
    });
  });
    $.expr[":"].contains = $.expr.createPseudo(function(arg) {
      return function( elem ) {
      return $(elem).text().toUpperCase().indexOf(arg.toUpperCase()) >= 0;
    };
  });
  //Apply for an account bike shop name 
  $(document).ready(function(){
    $("#address1").keyup(function(){
      var a=$("#address1").val();
      $("#bikeshopname").val(a);
    });
    // auto copying company name in first name.
  $(".customer-account-create #company").keyup(function(){
    $(".customer-account-create #firstname").val($(this).val());
  });
  
  });
  //================ catagory page title word limit =====
  //============blog category active link======
  $(document).ready(function() {
    $(".amblog-categories [href]").each(function() {
      if (this.href == window.location.href) {
        $(this).addClass("active");
      }
    });
  });
  //============blog share button ======
  $(document).ready(function(){
    $(".share-icon").click(function(){
      $(this).parent().siblings(".addthis_inline_share_toolbox").toggle();
    });
  });
  //========orderbysku======
  var isMiniorderActive = false;
  $(".nav-2").on("mouseover", function () {
    isMiniorderActive = true;
    $(".orderbyskupagemini").fadeIn("slow");
  });
  $(".nav-2").on("mouseleave", function () {
    isMiniorderActive = false;
    setTimeout(function () {
      if(isMiniorderActive == false)
      $(".orderbyskupagemini").fadeOut("slow");
    },500);
  });
  $(".orderbyskupagemini").mouseover(function(){
    isMiniorderActive = true;
  });
  $(".orderbyskupagemini").mouseleave(function(){
    $(".orderbyskupagemini").fadeOut("slow");
  });  
  //============pdp sku postion when star rating is not available=========//
  $(document).ready(function(){
    if ($(".catalog-product-view .product-reviews-summary").hasClass("empty")) {
      $(".catalog-product-view .product-info-stock-sku").addClass('pdp-product-info-sku');
    }
  });
  //============search box pop show and hide=========//
  $(document).ready(function(){
    $('#searh-click').click(function(){
      $('#myModal').show();
    });
    $('.close').click(function () {
     $('#myModal').hide();
    });
  });
  //============search box pop show and hide=========//
  $(document).ready(function(){
    $('.product-item-name').click(function(){
      $('#titleModal').show();
    });
    $('.close').click(function () {
     $('#titleModal').hide();
    });
  });
  //============hide all filters except category and brand=========//
  $(document).ajaxComplete(function() {
    if($(".page-with-filter.page-products.categorypath-catalogs").hasClass("category-catalogs" ))
    {
      $("div.filter-options-item:not(#hafiz-aw-filter-cat,#hafiz-aw-filter-brand,#hafiz-aw-filter-aw_sales)").hide();
    }
  });
  $(document).ready(function(){
    if($(".page-with-filter.page-products.categorypath-catalogs").hasClass("category-catalogs" ))
    {
      $("div.filter-options-item:not(#hafiz-aw-filter-cat,#hafiz-aw-filter-brand,#hafiz-aw-filter-aw_sales)").hide();
    }
  });
  $(document).ready(function(){
    if($(".filter-options-item .items li.item").is("#disabled_attribute"))
    {
        $( ".item.show-more span" ).each(function( index ) {
            if ($(this).text().indexOf('less') == -1 && $(this).attr('class') == 'show'){
                $(this).trigger('click');
            }
            $('li.item.show-more').hide();
        });
    }
    //hide labels with no or disable values
    $(".filter-options-item").each(function(index,value) { 
        var flag  = true;  
        // console.log(index);
        $(this).find('.items li').each(function(inn,valuee) {  
            var id = $(valuee).attr('id'); 
            if(id != 'disabled_attribute' && $(valuee).attr('class').indexOf('show-more')== -1){
                flag = false;  
            }
        });  
        if(flag == true){
            $(this).addClass("disable_label");
        }
        // $('.filter-options-item.disable_label').not(":last").hide();
        $('.filter-options-item.disable_label').not('#hafiz-aw-filter-color').hide();
    });
  });
  $(document).ready(function(){
      var flag  = true; 
      $("#hafiz-aw-filter-color .swatch-attribute-options.clearfix div").each(function(index,value) { 

              if($(this).attr('class').indexOf('disabled') == -1){
                  flag = false;  
              } 
      });  
      if(flag == true) { 
          $('#hafiz-aw-filter-color').addClass("disable_color");
      }
      $('.filter-options-item.disable_color').hide();
  });
  $(document).ajaxComplete(function(){
    if($(".filter-options-item .items li.item").is("#disabled_attribute"))
    {
        $( ".item.show-more span" ).each(function( index ) {
            if ($(this).text().indexOf('less') == -1 && $(this).attr('class') == 'show'){
                $(this).trigger('click');
            }
            $('li.item.show-more').hide();
        });
    }
    //hide labels with no or disable values
    $(".filter-options-item").each(function(index,value) { 
        var flag  = true;  
        // console.log(index);
        $(this).find('.items li').each(function(inn,valuee) {  
            var id = $(valuee).attr('id'); 
            if(id != 'disabled_attribute' && $(valuee).attr('class').indexOf('show-more')== -1){
                flag = false;  
            }
        });  
        if(flag == true){
            $(this).addClass("disable_label");
        }
        // $('.filter-options-item.disable_label').not(":last").hide();
        $('.filter-options-item.disable_label').not('#hafiz-aw-filter-color').hide();
    });
  });
  //hide labels with no or disable values
  $(document).ajaxComplete(function(){
      var flag  = true; 
      $("#hafiz-aw-filter-color .swatch-attribute-options.clearfix div").each(function(index,value) { 

              if($(this).attr('class').indexOf('disabled') == -1){
                  flag = false;  
              } 
      });  
      if(flag == true) { 
          $('#hafiz-aw-filter-color').addClass("disable_color");
      }
      $('.filter-options-item.disable_color').hide();
  });
  //hide labels with no or disable values
  $(document).ready(function(){
    $(".product-item-details").hasClass("sale-end-block-category" )
    $(".item.product.product-item").addClass('sale-end-class');
  });

});
